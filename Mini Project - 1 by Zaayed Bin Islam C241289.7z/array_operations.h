// Created on 07-May-25
//

#ifndef MINI_PROJECT___1_ARRAY_OPERATIONS_H
#define MINI_PROJECT___1_ARRAY_OPERATIONS_H
void init(int arr[],int size);
int binary_search(int item, int arr[], int size);
void searchItem(int arr[], int size);
void insert(int arr[], int &size);
void deleteItem(int arr[], int &size);
void display(int arr[], int size);

#endif //MINI_PROJECT___1_ARRAY_OPERATIONS_H
